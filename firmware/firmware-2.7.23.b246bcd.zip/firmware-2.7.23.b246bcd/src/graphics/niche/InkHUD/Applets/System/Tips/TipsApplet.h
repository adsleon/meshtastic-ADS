#ifdef MESHTASTIC_INCLUDE_INKHUD

/*

    Shows info on how to use InkHUD
    - tutorial at first boot
    - additional tips in certain situation (e.g. bad shutdown, region unset)

*/

#pragma once

#include "configuration.h"

#include "graphics/niche/InkHUD/SystemApplet.h"

namespace NicheGraphics::InkHUD
{

class TipsApplet : public SystemApplet
{
  protected:
    enum class Tip {
        WELCOME,
        FINISH_SETUP,
        PICK_REGION,
        SAFE_SHUTDOWN,
        CUSTOMIZATION,
        BUTTONS,
        ROTATION,
    };

  public:
    TipsApplet();

    void onRender(bool full) override;
    void onForeground() override;
    void onBackground() override;
    void onButtonShortPress() override;
    void onExitShort() override;

  protected:
    void renderWelcome(); // Very first screen of tutorial
#if defined(T5_S3_EPAPER_PRO)
    void renderT5S3ButtonsTip();
#endif

    std::deque<Tip> tipQueue; // List of tips to show, one after another

    WindowManager *windowManager = nullptr; // For convenience. Set in constructor.
};

} // namespace NicheGraphics::InkHUD

#endif
